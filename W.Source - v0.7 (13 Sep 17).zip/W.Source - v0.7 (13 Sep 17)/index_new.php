<!DOCTYPE PHP>

	<?
	require_once 'vendor/autoload.php';
	$elemeno = new \Elemeno\Client('8a3d4766-9750-11e7-898a-77b3603329e7'); // production API
	// $elemeno = new \Elemeno\Client('6339f1b0-8caa-11e7-a31a-3feebadaf301'); // test API
	
	$page1 = $elemeno->getSingle('hero-line')->data->content
	?>


<html>
	<head>
        <title><? print_r($page1->wtitle); ?></title>

		<link href="https://netdna.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
		<script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.php" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
     
        <!-- 2nd cusgtom CSS - ETE -->
        <link rel="stylesheet" href="assets/css/custom.css">
        
		<!-- Add to homescreen for Chrome on Android -->
		<meta name="mobile-web-app-capable" content="yes">
		<link rel="icon" sizes="192x192" href="images/android-desktop.png">

		<!-- Add to homescreen for Safari on iOS -->
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-title" content="Fyrtarn - It just works.">
		<link rel="apple-touch-icon-precomposed" href="images/ios-desktop.png">

		<!-- Tile icon for Win8 (144x144 + tile color) -->
		<meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
		<meta name="msapplication-TileColor" content="#3372DF">

		<link rel="shortcut icon" href="images/favicon.png">

		<script src="https://use.fontawesome.com/8421dbe9cc.js"></script>
		
        <script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
 		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
 		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
 		})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

 		ga('create', 'UA-106393931-1', 'auto');
 		ga('send', 'pageview');

		</script>
        
	
    </head>
	<body class="landing">

		<div id="page-wrapper">
		
		


			<!-- Header -->
				<header id="header" class="alt">
					<h1><a href="#"><img src="images/logo.png" height="40"></h1>
					<nav id="nav">
						<ul>
							<li><a href="#<? print_r(preg_replace('/ /', '_', $page1->menu1));?>"><? print_r($page1->menu1); ?> </a></li>
							<li><a href="#<? print_r(preg_replace('/ /', '_', $page1->menu2));?>"><? print_r($page1->menu2); ?></a></li>
                            <li><a href="#<? print_r(preg_replace('/ /', '_', $page1->menu3));?>"><? print_r($page1->menu3); ?></a></li>
<!-- 
                            <li><a href="#<? print_r(preg_replace('/ /', '_', $page1->menu4));?>"><? print_r($page1->menu4); ?></a></li>
 -->
							
<!-- 
							if you make the element below a "button" instead of an anchor, the modal works.
 -->
							<li><button class="button" href="#loginModal" data-target=".modal#loginModal" data-toggle="modal"><? print_r($page1->act1); ?></button></li>
									  

						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">
					<h2><? print_r($page1->heroTitle); ?></h2>
					<p><? print_r($page1->heroLine); ?></p>
					<ul class="actions">
						<li><a href="#<? print_r(preg_replace('/ /', '_', $page1->act2));?>" class="button special"><? print_r($page1->act2); ?></a></li>
						<li><a href="#<? print_r(preg_replace('/ /', '_', $page1->act2));?>" class="button"><? print_r($page1->act3); ?></a></li>
					</ul>
				</section>

			<!-- <? print_r($page1->menu1); ?> -->
				<section id="<? print_r(preg_replace('/ /', '_', $page1->menu1));?>" class="container">

					<section class="box special">
						<header class="major">
							<h2><? print_r($page1->mainTitle); ?></h2>
							<p><? print_r($page1->mainLine->markdown); ?></p>
						</header>
						<span class="image featured"><img src="<? print_r($elemeno->getSingle('website-images')->data->content->main->imageUrl); ?>" alt="" /></span>
					</section>


<!-- 
				Offerings section - <? print_r(preg_replace('/ /', '_', $page1->menu2));?>
 -->

					<section id = "<? print_r(preg_replace('/ /', '_', $page1->menu2));?>" class="box special features">
						<div class="features-row">
						<?
						$items = $elemeno->getCollectionItems('services')->data;
						$i = 0;
						foreach($items as $item):
						?>

						<section>
							<span class=<?php echo("\"icon major ");
							print_r($item->content->svcIcon->markdown);
							echo (" accent2\">"); 
							?>
							</span>
							<h3><?php print_r($item->title); ?></h3>
							<p><?php print_r($item->content->svcDescrip->markdown); ?></p>

						</section>

						<?php
							if (++$i == 2) {$i = 0; 
								echo("</div><div class=\"features-row\">");
								} 
							endforeach;
						?>

						</div>
					</section>

				</section>

<!--
				Start ideas section: <? print_r(preg_replace('/ /', '_', $page1->menu3));?>
 -->

				<section id = "<? print_r(preg_replace('/ /', '_', $page1->menu3));?>">
					<div class="row">

					<? 	$items = $elemeno->getCollectionItems('blog-post')->data;
 
						 foreach($items as $item):
						?>
						<div class="6u 12u(narrower)">
							<section class="box special">
								<span class="image featured"><img src="<? print_r($item->content->thumbImage->imageUrl); ?>" alt="" /></span>
								<h3><?php print_r($item->title); ?></h3>
								<p><?php print_r($item->content->teaser); ?></p><br><br>
								<ul class="actions">
									<li><a href="post.php?id=<?php print_r($item->id); ?>" class="button alt">Learn More</a></li>
								</ul>
							</section>

						</div>
						<? endforeach; ?>
					</div>

				</section>

			<!-- Call to action <? print_r(preg_replace('/ /', '_', $page1->act2));?> -->
				<section class="box" id="<? print_r(preg_replace('/ /', '_', $page1->act2));?>">
					<h2><? print_r($page1->signTitle); ?></h2>
					<p><? print_r($page1->signLine->markdown); ?><br><br></p>

						<form action="//fyrtarn.us16.list-manage.com/subscribe/post?u=1f24302432a2cd3ea58801b7c&amp;id=8e1c37a3e1" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>						<div class="form-group">
							<label for="mce-NAME" style="color:fff"><p>Name</p></label>
							<input type="text" class="form-control" value="" name="NAME" class="" id="mce-NAME">
						</div>
						<div class="form-group">
							<label for="mce-EMAIL" style="color:fff">Email Address</label>
							<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL">
						</div>
						<div class="input-group" id="input-group">
							<strong><p>Please help me with: </p></strong><br>
							<ul style="list-style: none;"><li><input type="checkbox" value="1" name="group[1959][1]" id="mce-group[1959]-1959-0"><label for="mce-group[1959]-1959-0">Demo</label></li>
								<li><input type="checkbox" value="4" name="group[1959][4]" id="mce-group[1959]-1959-2"><label for="mce-group[1959]-1959-2">Strategy</label></li>
								<li><input type="checkbox" value="2" name="group[1959][2]" id="mce-group[1959]-1959-1"><label for="mce-group[1959]-1959-1">Pilot</label></li>
								<li><input type="checkbox" value="8" name="group[1959][8]" id="mce-group[1959]-1959-3"><label for="mce-group[1959]-1959-3">Business Case</label></li>
							</ul><br>
						</div>

   					    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_1f24302432a2cd3ea58801b7c_8e1c37a3e1" tabindex="-1" value=""></div>
						<script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script><script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='NAME';ftypes[1]='text';}(jQuery));var $mcj = jQuery.noConflict(true);</script>


						<button type="submit" class="button alt"><i class="fa fa-envelope-o"></i> Subscribe</button>
					</form>

				</section>


<!-- 
						<style type="text/css">
							#mc_embed_signup{background:#fff; clear:left; font:14px Helvetica,Arial,sans-serif; }
							/* Add your own MailChimp form style overrides in your site stylesheet or in this style block.
							   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
						</style>
						<div id="mc_embed_signup">
						<form action="//fyrtarn.us16.list-manage.com/subscribe/post?u=1f24302432a2cd3ea58801b7c&amp;id=8e1c37a3e1" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
						   <div id="mc_embed_signup_scroll">
							<h2>Subscribe to our mailing list</h2>
						<div class="indicates-required"><span class="asterisk">*</span> indicates required</div>
						<div class="mc-field-group">
							<label for="mce-EMAIL">Email Address  <span class="asterisk">*</span>
						</label>
							<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL">
						</div>
						<div class="mc-field-group">
							<label for="mce-FNAME">First Name </label>
							<input type="text" value="" name="FNAME" class="" id="mce-FNAME">
						</div>
						<div class="mc-field-group">
							<label for="mce-LNAME">Last Name </label>
							<input type="text" value="" name="LNAME" class="" id="mce-LNAME">
						</div>
							<div id="mce-responses" class="clear">
								<div class="response" id="mce-error-response" style="display:none"></div>
								<div class="response" id="mce-success-response" style="display:none"></div>
							</div>    <!~~ real people should not fill this in and expect good things - do not remove this or risk form bot signups~~>
						   <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_1f24302432a2cd3ea58801b7c_8e1c37a3e1" tabindex="-1" value=""></div>
						   <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
						   </div>
						</form>
						</div>
						<script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script><script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';}(jQuery));var $mcj = jQuery.noConflict(true);</script>
						<!~~End mc_embed_signup~~>
 -->



			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">

					<? 	$items = $elemeno->getCollectionItems('social-accounts')->data;
					 foreach($items as $item):	?>
						
						<li><a href="<?print_r($item->content->uRL); ?>" class="icon <?php print_r($item->content->icon); ?>"><span class="label"><?php print_r($item->title); ?> </span></a></li>

					<?
					endforeach;
					?>


					</ul>
					<ul class="copyright">
						<li>&copy; Fyrtarn. All rights reserved.</li><li>2017 </li>
					</ul>
				</footer>
    
    
                
  		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>


	<!-- Modal -->
	<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
	    <div id="login-overlay" class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true"  class="fa fa-close"> </span><span class="sr-only">Close</span></button>
              <h4 class="modal-title" id="loginModalLabel">Login to fyrtarn.com</h4>
          </div>

			<div class="modal-body">
		<div class="row" style="display:block">
		  <div class="6u 12u(mobilep)">
			  <div class="well">
				  <form id="loginForm" method="POST" action="/login/" novalidate="novalidate">
					  <div class="form-group">
						  <label for="username" class="control-label">Username</label>
						  <input type="text" class="form-control" id="username" name="username" value="" required="" title="Please enter your username" placeholder="example@gmail.com">
						  <span class="help-block"></span>
					  </div>
					  <div class="form-group">
						  <label for="password" class="control-label">Password</label>
						  <input type="password" class="form-control" id="password" name="password" value="" required="" title="Please enter your password">
						  <span class="help-block"></span>
					  </div>
					  <div id="loginErrorMsg" class="alert alert-error hide">Wrong username or password</div>
					  <div class="checkbox">
						  <label>
							  <input type="checkbox" name="remember" id="remember"> Remember login
						  </label>
					  </div>
					  <button type="submit" class="btn btn-success btn-block">Login</button>
				  </form>
			  </div>
		  </div>
		  <div class="6u 12u(mobilep)">
			  <p class="lead">Register now:</p>
			  <ul class="list-unstyled" style="line-height: 2" fontsize=10>
				  <li><span class="fa fa-check text-success"></span> Access our Strategy Library</li>
				  <li><span class="fa fa-check text-success"></span> Get Exclusive Invitations</li>
				  <li><span class="fa fa-check text-success"></span> Request a Demo</li>
				  <li><span class="fa fa-check text-success"></span> Arrange a Pilot</li>
			  </ul>
			  <p><a href="/new-customer/" class="btn btn-info btn-block">Yes please, register now!</a></p>
		  </div>
		</div>
	  </div>
		</div>
	</div>
	</div>

	</body>
	
</html>