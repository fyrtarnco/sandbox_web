<?
require_once 'vendor/autoload.php';
$elemeno = new \Elemeno\Client('6339f1b0-8caa-11e7-a31a-3feebadaf301'); ?>

<!-- 
// $test = $elemeno->getSingle('about-us')
// print_r($test.content.markdown);

// print_r($elemeno->getSingle('website-images')->data->content->main);

// print_r($elemeno->getCollection('services'));

// foreach($info as $item):
// 	print_r($item);
// 	end foreach;

// print_r($elemeno->getSingle('website-images')->data->content->main->imageUrl);
 -->

<!-- 
		<? $page1 = $elemeno->getSingle('hero-line')->data->content;

		print_r($page1); ?>

 -->


		<? 
		
		$options = [
			'byId' => true
		];
		
 		$page1 = $elemeno->getCollectionItem('blog-post',$_GET["id"],$options);
 		
 		
// 		print_r($_GET["id"]); 

		print_r($page1->data->title); 
		print_r($page1->data->content->blogBody->markdown); 
		print_r($page1->data->content->blogImage->imageUrl); 

		?>



<!-- 


<?
 	$items = $elemeno->getCollectionItems('social-accounts')->data;
 
 	print_r($items);
 
     foreach($items as $item):
 	?>
 	<?php print_r($item->id); ?> 
 	<b>Title: </b> 
 	<?php print_r($item->title); ?> 
 	<b>Body: </b> 
 	<?php print_r($item->content->icon); ?> 
 	<b>URL: </b> 
 	<?php print_r($item->content->uRL); ?> 
 	<br/>
 	<?
 		endforeach;
 	?>
 ~~>

 -->

<!-- 
<?
							print_r($elemeno->getSingle('hero-line')->data->content->heroLine);

							print_r($elemeno->getSingle('hero-line')->data->content->heroTitle);
							print_r($elemeno->getSingle('hero-line')->data->content->menu1);
							print_r($elemeno->getSingle('hero-line')->data->content->menu2);
							print_r($elemeno->getSingle('hero-line')->data->content->act1);
							print_r($elemeno->getSingle('hero-line')->data->content->act2);

							print_r($elemeno->getSingle('hero-line'));

?>
 ~~>
 
<!~~ 
 
 stdClass Object (
 	 [status] => success 
 	 [data] => stdClass Object ( 
 	 	[id] => bfa60952-8b1a-11e7-bead-bf61160ec5c8 
 	 	[slug] => services [title] => Services 
 	 	[projectId] => b1f364f2-8297-11e7-94e6-5fc31aa583fe 
 	 	[dateCreated] => 2017-08-27T11:27:45.882Z 
 	 	[dateUpdated] => 2017-08-27T11:29:58.323Z [published] => 1 
 	 		) 
 	 [links] => stdClass Object ( 
 	 	[self] => https://api.elemeno.io/v1/collections/services 
 	 	[items] => https://api.elemeno.io/v1/collections/services/items
 	 		) 
 	 [meta] => stdClass Object ( 
 	 	[totalRecords] => 1 
 	 	[totalPages] => 1 
 	 		) 
 	 	)
 ~~>

// image: print_r($elemeno->getSingle('website-images')->data->content->main);
// 
// stdClass Object ( 
// 	[dateCreated] => 2017-09-05T07:05:21.105Z 
// 	[dateUpdated] => 2017-09-05T07:05:21.105Z 
// 	[title] => pic01.jpg 
// 	[fileSize] => 55185 
// 	[mimeType] => image/jpeg 
// 	[metaData] => stdClass Object ( 
// 		[width] => 1200 
// 		[colors] => stdClass Object ( 
// 			[palette] => 
// 			[dominant] => stdClass Object ( 
// 				[rgb] => stdClass Object ( 
// 					[b] => 182 
// 					[g] => 178 
// 					[r] => 177 )
// 				[hex] => B1B2B6 
// 				[isLight] => 1 ) 
// 			) 
// 		[height] => 393 
// 		[alternativeText] => 
// 		[copyrightInformation] => 
// 		) 
// 	[tags] => Array ( ) 
// 	[imageUrl] => https://d1o9o9r2qlybfc.cloudfront.net/full/4fa7e516-3a8c-4d44-a3e1-3b9e850f6a6f.jpg 
// 	[thumbnails] => stdClass Object ( ) ) // item: 
// 



Array ( [0] => stdClass Object ( 
	[id] => c80e1614-92ec-11e7-a7fc-dbb640caca2d 
	[slug] => zerotouch-deployment 
	[title] => Zero-touch Deployment 
	[dateCreated] => 2017-09-06T10:18:52.431Z 
	[dateUpdated] => 2017-09-06T10:18:52.431Z 
	[datePublished] => 2017-09-06T10:18:52.431Z 
	[published] => 1 
	[content] => stdClass Object ( 
		[blogBody] => stdClass Object ( 
			[markdown] => With the evolution of MDM suites and the manageability of Mac OS, the time is right to start managing laptops like mobile devices. Full-disk-wipe imaging strategies have gone the way of the dodo, and we can trust but verify the base build, then configure from there. This means quicker time to production for end users, less time spent waiting for machines between delivery and use, and a better overall experience. It also means that we can spend more resources enabling and smoothing the experience, rather than maintaining the perpetually out-of-date "gold disk" SOE. 
			[html] =>
			) 
		[blogImage] => stdClass Object ( 
			[dateCreated] => 2017-08-27T11:12:25.546Z 
			[dateUpdated] => 2017-08-27T11:12:25.546Z 
			[title] => macbook-pro@2x.png 
			[fileSize] => 202556 
			[mimeType] => image/png 
			[metaData] => stdClass Object ( 
				[width] => 1844 
				[colors] => stdClass Object ( [palette] => [dominant] => stdClass Object ( [rgb] => stdClass Object ( [b] => 64 [g] => 53 [r] => 49 ) [hex] => 313540 [isLight] => ) ) 
				[height] => 1074 
				[alternativeText] => 
				[copyrightInformation] => ) 
			[tags] => Array ( ) 
			[imageUrl] => https://d1o9o9r2qlybfc.cloudfront.net/full/643bfcfd-5585-4654-bef7-902b09746952.png 
			[thumbnails] => stdClass Object ( ) ) ) [links] => stdClass Object ( [self] => https://api.elemeno.io/v1/collections/blog-post/items/zerotouch-deployment [collection] => https://api.elemeno.io/v1/collections/blog-post ) ) [1] 

 	 
 -->