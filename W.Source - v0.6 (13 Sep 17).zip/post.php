<!DOCTYPE PHP>

	<?
	require_once 'vendor/autoload.php';
	$elemeno = new \Elemeno\Client('6339f1b0-8caa-11e7-a31a-3feebadaf301');

	$page1 = $elemeno->getSingle('hero-line')->data->content;

	$options = [
		'byId' => true
	];
	
	$item = $elemeno->getCollectionItem('blog-post',$_GET["id"],$options);
 		
	?>


<html>
	<head>
        <title><? print_r($page1->wtitle); ?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.php" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
     
		<!-- Add to homescreen for Chrome on Android -->
		<meta name="mobile-web-app-capable" content="yes">
		<link rel="icon" sizes="192x192" href="images/android-desktop.png">

		<!-- Add to homescreen for Safari on iOS -->
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-title" content="Fyrtarn - It just works.">
		<link rel="apple-touch-icon-precomposed" href="images/ios-desktop.png">

		<!-- Tile icon for Win8 (144x144 + tile color) -->
		<meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
		<meta name="msapplication-TileColor" content="#3372DF">

		<link rel="shortcut icon" href="images/favicon.png">

		<script src="https://use.fontawesome.com/8421dbe9cc.js"></script>
	
    </head>
    
	<body>
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1><a href="index.php"><img src="images/logo.png" height="40"></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php#<? print_r(preg_replace('/ /', '_', $page1->menu1));?>"><? print_r($page1->menu1); ?> </a></li>
							<li><a href="index.php#<? print_r(preg_replace('/ /', '_', $page1->menu2));?>"><? print_r($page1->menu2); ?></a></li>
                            <li><a href="index.php#<? print_r(preg_replace('/ /', '_', $page1->menu3));?>"><? print_r($page1->menu3); ?></a></li>
<!-- 
                            <li><a href="index.php#<? print_r(preg_replace('/ /', '_', $page1->menu4));?>"><? print_r($page1->menu4); ?></a></li>
 -->
							
							<li><a href="index.php#" class="button"><? print_r($page1->act1); ?></a></li>
						</ul>
					</nav>
				</header>

			<!-- <? print_r($page1->menu1); ?> -->
				<section id="<? print_r(preg_replace('/ /', '_', $page1->menu1));?>" class="container">
					<header>
						<h2><? print_r($item->data->title); ?></h2>
						<p><? print_r($item->data->content->subtitle); ?></p>
					</header>
					<div class="box">
						<span class="image featured"><img src="<? print_r($item->data->content->blogImage->imageUrl);  ?>" alt="" /></span>
							<? print_r($item->data->content->blogBody->markdown); ?>
					</div>
				</section>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">

					<? 	$items = $elemeno->getCollectionItems('social-accounts')->data;
					 foreach($items as $item):	?>
						
						<li><a href="<?print_r($item->content->uRL); ?>" class="icon <?php print_r($item->content->icon); ?>"><span class="label"><?php print_r($item->title); ?> </span></a></li>

					<?
					endforeach;
					?>


					</ul>
					<ul class="copyright">
						<li>&copy; Fyrtarn. All rights reserved.</li><li>2017 </li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>